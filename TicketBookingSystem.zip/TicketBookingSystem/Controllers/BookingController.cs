﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TicketBookingSystem.Models;

namespace TicketBookingSystem.Controllers
{
    public class BookingController : Controller
    {
        dBContext con = new dBContext();
        // GET: Booking
        public ActionResult Index(string name,string email)
        {
            if(name!=null && email !=null)
            {
                var uData = con.UserDetails.Where(x=>x.Name==name && x.Email==email).Count();

                if(Convert.ToInt32(uData)>0)
                {
                    return PartialView("_BookingPage");
                }
                else
                {
                    return PartialView("_Error");
                }
            }
            return View();
        }
    }
}