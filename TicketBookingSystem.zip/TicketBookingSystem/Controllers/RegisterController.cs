﻿using System;
using System.Web.Mvc;
using TicketBookingSystem.Models;

namespace TicketBookingSystem.Controllers
{
    public class RegisterController : Controller
    {
        private dBContext con = new dBContext();
        /// <summary>
        /// Call and Get the Register page when we load the application for the first time
        /// </summary>
        /// <returns></returns>
        // GET: Register
        [HttpGet]
        public ActionResult Index()
        {
            Session.Abandon();
            return View();
        }

        [HttpPost]
        public ActionResult Index(UserDetails obj)

        {
            if (ModelState.IsValid)
            {
                UserDetails userDetail = new UserDetails
                {
                    Name = obj.Name,
                    Email = obj.Email,
                    RegisterDate = DateTime.Now
                };

                con.UserDetails.Add(userDetail);
                con.SaveChanges();

                ModelState.Clear();

                ViewBag.Message = "Record Save Successfully.";
            }
            return View();
        }


        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
    }
}