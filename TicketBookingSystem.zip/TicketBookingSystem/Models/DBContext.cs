﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace TicketBookingSystem.Models
{
    public class dBContext : DbContext
    {
        public dBContext() : base("Data")
        {
        }

        public DbSet<UserDetails> UserDetails { get; set; }
        public DbSet<TicketBooking> TicketBooking { get; set; }
    }
}